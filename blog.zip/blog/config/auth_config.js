module.exports ={
    secret:"secret-key-of-blog",
    Roles :['ADMIN', 'BLOG']
}